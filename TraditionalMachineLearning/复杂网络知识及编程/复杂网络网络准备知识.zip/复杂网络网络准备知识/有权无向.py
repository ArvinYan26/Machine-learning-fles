import networkx as nx
import matplotlib.pyplot as plt
from pylab import mpl
import os
#解决显示中文问题
mpl.rcParams['font.sans-serif'] = ['SimHei']   # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False     # 解决保存图像是负号'-'显示为方块的问题

nodes = {'a','b','c','d','e'}

data = {'a':{'b':1},'c':{'a':2},'e':{'b':3},'b':{'a':4}}
#生成 有权无向边数据
def weight_nodi_edge(data):
    nodi_edge_set = set()
    nodi_edge_weight_set = set()
    for node_k, v in data.items():
        node_v = list(v.keys())[0]
        if (node_k, node_k) not in nodi_edge_set and (node_v, node_k) not in nodi_edge_set:
            nodi_edge = (node_k, node_v)
            nodi_edge_set.add(nodi_edge)
    for ndi_eg in nodi_edge_set:
        nd1 = ndi_eg[0]
        nd2 = ndi_eg[1]
        nd1nd2wgt = data.get(nd1).get(nd2)
        if nd1nd2wgt is None:
            nd1nd2wgt = 0
        nd2nd1wgt = data.get(nd2).get(nd1)
        if nd2nd1wgt is None:
            nd2nd1wgt = 0
        weight = nd1nd2wgt+nd2nd1wgt
        nodi_edge_weight = (nd1,nd2,weight)
        nodi_edge_weight_set.add(nodi_edge_weight)
    return nodi_edge_weight_set
print(weight_nodi_edge(data))




#有权无向图(权重值没有实现为边的粗细，节点的大小)
#希望同志们集思广益
def weight_no_di_graph(data,nodes,Save=False):
    G = nx.Graph()
    G.add_nodes_from(nodes)
    # 有权无向边
    edgedata = weight_nodi_edge(data)
    G.add_weighted_edges_from(edgedata)
    nx.draw(G, with_labels=True)
    if Save:
        picpath = os.getcwd() + '\\noweight_nodi_graph.png'
        plt.savefig(picpath)
    plt.show()