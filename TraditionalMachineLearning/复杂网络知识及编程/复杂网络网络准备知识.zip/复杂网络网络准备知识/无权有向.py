import networkx as nx
import matplotlib.pyplot as plt
from pylab import mpl
#解决显示中文问题
mpl.rcParams['font.sans-serif'] = ['SimHei']   # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False     # 解决保存图像是负号'-'显示为方块的问题

nodes = {'a','b','c','d','e'}
data = {'a':{'b':1},
        'c':{'a':2},
        'e':{'b':3},
        'b':{'a':4}}

#生成 无权有向边数据
def noweight_di_edge(data):
    edge_set = set()
    for node_k,v in data.items():
        node_v = list(v.keys())[0]
        edge = (node_k,node_v)
        edge_set.add(edge)
    return edge_set

print(noweight_di_edge(data))















# 无权有向图
def noweight_di_graph(data,nodes,Save=False):
    DG = nx.DiGraph()
    DG.add_nodes_from(nodes)
    # 无权有向边
    edgedata = noweight_di_edge(data)
    DG.add_edges_from(edgedata)
    nx.draw(DG, with_labels=True)
    if Save:
        picpath = os.getcwd() + '\\noweight_nodi_graph.png'
        plt.savefig(picpath)
    plt.show()



