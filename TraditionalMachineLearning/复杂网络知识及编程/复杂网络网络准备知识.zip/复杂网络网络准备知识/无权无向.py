import networkx as nx
import matplotlib.pyplot as plt
from pylab import mpl
import os
#解决显示中文问题
mpl.rcParams['font.sans-serif'] = ['SimHei']   # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False     # 解决保存图像是负号'-'显示为方块的问题

nodes = {'a','b','c','d','e'}
data = {'a':{'b':1},
        'c':{'a':2},
        'e':{'b':3},
        'b':{'a':4}}


#生成 无权无向边数据
def noweight_nodi_edge(data):
    edge_set = set()
    for node_k,v in data.items():
        node_v = list(v.keys())[0]
        if (node_k,node_v) not in edge_set and (node_v,node_k) not in edge_set:
            edge = (node_k, node_v)
            edge_set.add(edge)
    return edge_set

print(noweight_nodi_edge(data))






#无权无向图
def noweight_nodi_graph(data,nodes,Save=False):
    G = nx.Graph()
    G.add_nodes_from(nodes)
    #无权v边
    edgedata = noweight_nodi_edge(data)
    G.add_edges_from(edgedata)
    nx.draw(G, with_labels=True)
    if Save:
        picpath = os.getcwd()+'\\noweight_nodi_graph.png'
        plt.savefig(picpath)
    plt.show()

#noweight_nodi_graph(data,nodes,Save=False)
