import networkx as nx
import matplotlib.pyplot as plt
from pylab import mpl
import os
#解决显示中文问题
mpl.rcParams['font.sans-serif'] = ['SimHei']   # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False     # 解决保存图像是负号'-'显示为方块的问题

nodes = {'a','b','c','d','e'}
data = {'a':{'b':1},
        'c':{'a':2},
        'e':{'b':3},
        'b':{'a':4}}

#生成 有权有向边数据
def weight_di_edge(data):
    edge_set = []
    for node_k,v in data.items():
        node_v = list(v.keys())[0]
        weight = data.get(node_k).get(node_v)# weight = list(v.values())[0]
        edg = (node_k,node_v,weight)
        edge_set.append(edg)
    return edge_set
print(weight_di_edge(data))








#有权有向图(权重值没有实现为边的粗细，节点的大小)
def weight_di_graph(data,nodes,Save=False):
    DG = nx.DiGraph()
    DG.add_nodes_from(nodes)
    # 有权有向边
    edgedata = weight_di_edge(data)
    DG.add_weighted_edges_from(edgedata)
    nx.draw(DG, with_labels=True)
    if Save:
        picpath = os.getcwd() + '\\noweight_nodi_graph.png'
        plt.savefig(picpath)
    plt.show()