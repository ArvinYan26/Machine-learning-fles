import networkx as nx
import matplotlib.pyplot as plt
from pylab import mpl

#解决显示中文问题
mpl.rcParams['font.sans-serif'] = ['SimHei']   # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False       # 解决保存图像是负号'-'显示为方块的问题




nodes_data = ['a','b','c','d']
raw_data = ['acW','aca','caE','ec','cd','dc']

#nodesdata,raw_data均为列表格式
#在本案例中，raw_data是英文字母串，是可迭代对象
#如果在中文中，raw_data形如下面，列表中含有多个元素列表（我自己建的词）。每个元素列表含有多个元素。
#raw_data = [['我','叫','大邓'],['喜欢','Python'],['研究方向','市场营销','及','消费者行为学']]
def data(nodes_data, raw_data):
    node_freq = {}  # 节点词频，格式{node：frequency}
    #有向关系数据结构
    di_relationships = {}  # 关系字典，格式{source_node:{target_node:weight}}
    line_nodes = []        # 保存raw_data中每个元素列表中出现的节点
    for line in raw_data:
        line_nodes.append([])  #建立[..,[]]容器，方便后面收集raw_data中每个元素列表中出现的元素（满足该元素在nodesdata列表中）
        for node in line:
            if node in nodes_data:          #如果raw_data中元素列表中的元素在nodesdata中
                line_nodes[-1].append(node) #将满足条件的元素添加到line_nodes中
                if node_freq.get(node) is None:
                    node_freq[node] = 0
                    di_relationships[node] = {}
                node_freq[node]+=1
    #大邓已经把最难的前半部分注释了，后面你自己琢磨琢磨吧
    for line in line_nodes:
        for node1 in line:
            for node2 in line:
                if node1 == node2:
                    continue
                if di_relationships[node1].get(node2) is None:
                    di_relationships[node1][node2] = 1
                else:
                    di_relationships[node1][node2]+=1
    return (node_freq,di_relationships)


#生成 无权无向边数据
def noweight_nodi_edge(data):
    edge_set = set()
    for node_k,v in data.items():
        node_v = list(v.keys())[0]
        if (node_k,node_v) not in edge_set and (node_v,node_k) not in edge_set:
            edge = (node_k, node_v)
            edge_set.add(edge)
    return edge_set


#无权无向图
def noweight_nodi_graph(data,nodes,Save=False):
    G = nx.Graph()
    G.add_nodes_from(nodes)
    #无权v边
    edgedata = noweight_nodi_edge(data)
    G.add_edges_from(edgedata)
    nx.draw(G, with_labels=True)
    if Save:
        picpath = os.getcwd()+'\\noweight_nodi_graph.png'
        plt.savefig(picpath)
    plt.show()
data = data(nodes_data, raw_data)[1]
noweight_nodi_graph(data,nodes_data)







