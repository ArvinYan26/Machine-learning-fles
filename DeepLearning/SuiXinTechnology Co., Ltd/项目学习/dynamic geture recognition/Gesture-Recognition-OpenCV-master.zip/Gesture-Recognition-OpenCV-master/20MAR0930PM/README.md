Using Profile4.py
==================

Start the python script and wait for it to detect your face and black out that region. Position your palm exactly on small squares so that your hand completely covers all the squares, and press z. Now as soon as you see a rectangle enclosing the image of your hand, press f.