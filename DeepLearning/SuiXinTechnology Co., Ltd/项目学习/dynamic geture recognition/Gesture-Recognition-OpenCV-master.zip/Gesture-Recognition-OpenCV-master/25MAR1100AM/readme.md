YUV - Colour Space
===================
Use YUVTRACKER to learn for threshold values
Suggested Values:
Y: 0 to 255
U(Cb): 133 to 173
V(Cr): 77 to 127
Try adjusting them within these values to get the best threshold
