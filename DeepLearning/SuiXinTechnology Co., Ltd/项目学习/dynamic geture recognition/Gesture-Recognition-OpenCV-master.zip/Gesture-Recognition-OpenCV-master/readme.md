OpenCV Hand Gesture Recognition
===============================

This repo contains daily code updates for the opencv hand gesture recognition system.
Code snapshots maintained for ease of use by the evaluator
