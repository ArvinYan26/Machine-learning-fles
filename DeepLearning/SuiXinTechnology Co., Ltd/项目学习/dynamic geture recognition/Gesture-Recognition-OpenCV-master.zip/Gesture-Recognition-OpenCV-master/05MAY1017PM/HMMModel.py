class HMMModel:
	def __init__(self):
		num_states=0
		num_symbols=0
		num_obSeq=0
		transition=0
		output=0
		pi=0
		return
