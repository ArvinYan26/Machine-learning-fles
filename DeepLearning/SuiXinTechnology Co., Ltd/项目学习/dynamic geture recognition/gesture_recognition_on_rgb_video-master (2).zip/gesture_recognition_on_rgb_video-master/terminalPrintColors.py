# colors for prettier terminal outputs

class tcolors:
    HEADER = '\033[94m'
    ERR = '\033[91m'
    EMPH = '\033[96m'
    DBG = '\033[95m'
    ENDC = '\033[0m'
