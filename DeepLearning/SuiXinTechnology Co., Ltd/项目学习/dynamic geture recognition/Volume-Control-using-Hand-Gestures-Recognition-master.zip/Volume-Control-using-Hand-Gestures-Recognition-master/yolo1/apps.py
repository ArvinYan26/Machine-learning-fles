from django.apps import AppConfig


class ZetoConfig(AppConfig):
    name = 'zeto'
